package com.example.calculator.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CalculatorController {
	@GetMapping(path="/add/{num1}/{num2}")
	public String add(@PathVariable float num1, @PathVariable float num2) {
		
		return decimalCalc( String.valueOf(num1+num2));
	}
	
	@GetMapping(path="/subtract/{num1}/{num2}")
	public String subtract(@PathVariable float num1, @PathVariable float num2) {
		
		return decimalCalc( String.valueOf(num1-num2));
	}
	
	@GetMapping(path="/multiply/{num1}/{num2}")
	public String multiply(@PathVariable float num1, @PathVariable float num2) {
		
		return decimalCalc( String.valueOf(num1*num2));
	}
	
	@GetMapping(path="/divide/{num1}/{num2}")
	public String divide(@PathVariable float num1, @PathVariable float num2) {
		if(num2==0) {
			return "Cannot divide by zero";
		}
		return decimalCalc(String.valueOf((num1/num2)));
	}
	
	public String decimalCalc(String decimal) {
		String output[] = decimal.split("\\.");
		if(Integer.parseInt(output[1])>0) {
			return decimal;
		}
		return output[0];
	}
}
